package com.example.basicstorage545
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Color.BLACK
import android.graphics.Color.WHITE
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.provider.MediaStore
import android.widget.Switch
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.basicstorage545.R.*

class MainActivity : AppCompatActivity() {

    //private lateinit var button: Button
    private lateinit var buttonTwo: Button
    private lateinit var imageView: ImageView
    private lateinit var switchDark: Switch

    val sharedPrefs by lazy {
        getSharedPreferences(
            "${BuildConfig.APPLICATION_ID}_sharedPreferences",
            Context.MODE_PRIVATE
        )
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(layout.activity_main)

        //button = findViewById(id.editProfileBtn)
        buttonTwo = findViewById(id.switchBtn)
        imageView = findViewById(id.imageItem)
        var emailTest = findViewById<TextView>(id.emailText)
        var nameTest = findViewById<TextView>(id.nameText)
        var bioTest = findViewById<TextView>(id.bioText)
        var layoutItem = findViewById<ConstraintLayout>(id.viewLayout)
        var isDark = false;


        emailTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
        bioTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
        nameTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
        //button.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", WHITE))
        buttonTwo.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", WHITE))
        layoutItem.setBackgroundColor(sharedPrefs.getInt("BG_COLOR", WHITE))
        isDark = sharedPrefs.getBoolean("isDark", false)


        /*
        button.setOnClickListener(){
            imageSelection()
        }*/

        buttonTwo.setOnClickListener {

            if (isDark) {
                sharedPrefs.edit().putInt("TEXT_COLOR", WHITE).commit()
                sharedPrefs.edit().putInt("BUTTON_TEXT_COLOR", BLACK).commit()
                sharedPrefs.edit().putInt("BG_COLOR", BLACK).commit()
                sharedPrefs.edit().putBoolean("isDark",false).commit()
                sharedPrefs.edit().commit()

                emailTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",WHITE))
                bioTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",WHITE))
                nameTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",WHITE))
                //button.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", BLACK))
                buttonTwo.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", BLACK))
                layoutItem.setBackgroundColor(sharedPrefs.getInt("BG_COLOR", BLACK))
                isDark = sharedPrefs.getBoolean("isDark", false)
            } else {
                sharedPrefs.edit().putInt("TEXT_COLOR", BLACK).commit()
                sharedPrefs.edit().putInt("BUTTON_TEXT_COLOR", WHITE).commit()
                sharedPrefs.edit().putInt("BG_COLOR", WHITE).commit()
                sharedPrefs.edit().putBoolean("isDark",true).commit()
                sharedPrefs.edit().commit()

                emailTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
                bioTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
                nameTest.setTextColor(sharedPrefs.getInt("TEXT_COLOR",BLACK))
                //button.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", WHITE))
                buttonTwo.setTextColor(sharedPrefs.getInt("BUTTON_TEXT_COLOR", WHITE))
                layoutItem.setBackgroundColor(sharedPrefs.getInt("BG_COLOR", WHITE))
                isDark = sharedPrefs.getBoolean("isDark", true)

            }

        }
    }
/*
    private fun imageSelection(){
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, 100)
    }

    override fun onActivityResult(requestCode:Int, resultCode: Int, data:Intent?){
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 100 && resultCode == RESULT_OK)
        {
            imageView.setImageURI(data?.data)
        }
    }*/
}